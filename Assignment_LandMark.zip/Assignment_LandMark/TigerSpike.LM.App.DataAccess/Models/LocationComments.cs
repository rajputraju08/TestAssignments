﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TigerSpike.LM.App.DataAccess.Models
{
    public partial class LocationComments
    {
        [Key]
        public int Id { get; set; }
        public string LocationName { get; set; }
        public string LocationComment { get; set; }

        public string CurrentLocation {get; set;}
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public int? UserId { get; set; }
        public virtual User User { get; set; }
    }
}
