﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TigerSpike.LM.App.DataAccess.Models
{
    public partial class User
    {
        public User()
        {
            LocationComments = new HashSet<LocationComments>();
        }
        [Key]
        public int Id { get; set; }
        public string UserName { get; set; }

        public virtual ICollection<LocationComments> LocationComments { get; set; }
    }
}
