﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using TigerSpike.LM.App.DataAccess.Models;

namespace TigerSpike.LM.App.DataAccess.Context
{
    public partial class LMContext : DbContext
    {
        public LMContext()
        {
        }

        public LMContext(DbContextOptions<LMContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LocationComments> LocationComments { get; set; }
        public virtual DbSet<User> User { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                 optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Initial Catalog=LandMarkDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LocationComments>(entity =>
            {
                entity.Property(e => e.LocationComment).HasMaxLength(500);

                entity.Property(e => e.LocationName).HasMaxLength(150);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.LocationComments)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__LocationC__UserI__286302EC");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserName).HasMaxLength(100);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
