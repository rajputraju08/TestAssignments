﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.ExceptionHandling;
using System.Web.Http.Filters;

namespace Soln_LandMark_App.ExceptionHandler
{
        public class LMException : FilterAttribute,IExceptionFilter
    {
        public Task ExecuteExceptionFilterAsync(HttpActionExecutedContext actionExecutedContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public void OnException(ExceptionContext filterContext)
        {
            // To do exception handling and logging
        }
    }
}
