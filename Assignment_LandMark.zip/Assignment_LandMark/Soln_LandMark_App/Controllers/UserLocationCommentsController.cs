﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Soln_LandMark_App.ExceptionHandler;
using TigerSpike.LM.App.BusinessLogic;
using TigerSpike.LM.App.BusinessLogic.BusinessEntities;

namespace Soln_LandMark_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [LMException]
    public class UserLocationCommentsController : ControllerBase
    {
        private readonly ILocationBasedComment _ILocationBasedComment;

            public UserLocationCommentsController()
            {
                _ILocationBasedComment = new LocationBasedComment();
            }

        public string GetUserLocationComment(int userId)
        {
            return JsonConvert.SerializeObject(_ILocationBasedComment.GetUserLocationComment(userId));
        }

        public string GetUserCommentsByUserOrLocation(string userName, string locationName)
        {
            return JsonConvert.SerializeObject(_ILocationBasedComment.GetUserCommentsByUserOrLocation(userName,  locationName));
        }
        public string GetAllUserLocationComment()
        {
            return JsonConvert.SerializeObject(_ILocationBasedComment.GetAllUserLocationComment());
        }

        public bool AddCurrentLocationComments([FromBody] UserLocationComment userLocationComment)
        {
            return _ILocationBasedComment.AddCurrentLocationComments(userLocationComment);

        }
        
    }
}
