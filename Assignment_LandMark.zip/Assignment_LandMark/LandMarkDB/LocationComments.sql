﻿CREATE TABLE [dbo].[LocationComments]
(
	[Id] INT IDENTITY(1,1), 
    [LocationName] NVARCHAR(150) NULL, 
    [LocationComment] NVARCHAR(500) NULL, 
    [Longitude] FLOAT NULL, 
    [Latitude] FLOAT NULL, 
 	[UserId] int FOREIGN KEY REFERENCES [User](Id), 
    [CurrentLocation] NVARCHAR(100) NULL, 
    CONSTRAINT [PK_LocationComments] PRIMARY KEY ([Id])
)
