﻿CREATE TABLE [dbo].[User]
(
	[Id] INT IDENTITY(1,1), 
    [UserName] NVARCHAR(100) NULL, 
    CONSTRAINT [PK_User] PRIMARY KEY ([Id])
)
