﻿CREATE TABLE [dbo].[LocationComments] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [LocationName]    NVARCHAR (150) NULL,
    [LocationComment] NVARCHAR (500) NULL,
    [Longitude]       FLOAT (53)     NULL,
    [Latitude]        FLOAT (53)     NULL,
    [UserId]          INT            NULL,
    FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]), 
    CONSTRAINT [PK_LocationComments] PRIMARY KEY ([Id])
);

