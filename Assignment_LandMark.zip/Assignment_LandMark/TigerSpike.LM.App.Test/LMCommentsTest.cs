using System;
using Xunit;
using Moq;
using TigerSpike.LM.App.BusinessLogic.BusinessEntities;
using TigerSpike.LM.App.BusinessLogic;
using System.Collections.Generic;

namespace TigerSpike.LM.App.Test
{
    public class LMCommentsTest
    {
        [Fact]
        public void AddCurrentLocationCommentsTest()
        {
   
            UserLocationComment userLocationComment = new UserLocationComment();
            userLocationComment.Latitude = 2.01;
            userLocationComment.Longitude = 5.9;
            userLocationComment.LocationName = "TestLocation";
            userLocationComment.LocationComment = "TestComments";
            userLocationComment.UserId = 100;
          
            var mockLM = new Mock<ILocationBasedComment>();
            mockLM.Setup(x => x.AddCurrentLocationComments(userLocationComment)).Returns(true);
        }
        [Fact]
        public void GetAllUserLocationCommentTest()
        {
            UserLocationComment userLocationComment = new UserLocationComment();
            userLocationComment.Latitude = 2.01;
            userLocationComment.Longitude = 5.9;
            userLocationComment.LocationName = "TestLocation";
            userLocationComment.LocationComment = "TestComments";
            userLocationComment.UserId = 100;

            List<UserLocationComment> lstLMComment = new List<UserLocationComment>();
            lstLMComment.Add(userLocationComment);
            var mockLM = new Mock<ILocationBasedComment>();
            mockLM.Setup(x => x.GetAllUserLocationComment()).Returns(lstLMComment);

        }
        [Fact]
        public void GetUserCommentsByUserOrLocationTest()
        {
            UserLocationComment userLocationComment = new UserLocationComment();
            userLocationComment.Latitude = 2.01;
            userLocationComment.Longitude = 5.9;
            userLocationComment.LocationName = "TestLocation";
            userLocationComment.LocationComment = "TestComments";
            userLocationComment.UserId = 100;

            List<UserLocationComment> lstLMComment = new List<UserLocationComment>();
            lstLMComment.Add(userLocationComment);
            var mockLM = new Mock<ILocationBasedComment>();
            mockLM.Setup(x => x.GetUserCommentsByUserOrLocation("TestUser","TestLoction")).Returns(lstLMComment);
        }
        [Fact]
        public void GetUserLocationCommentTest()
        {
            
            UserLocationComment userLocationComment = new UserLocationComment();
            userLocationComment.Latitude = 2.01;
            userLocationComment.Longitude = 5.9;
            userLocationComment.LocationName = "TestLocation";
            userLocationComment.LocationComment = "TestComments";
            userLocationComment.UserId = 100;

            List<UserLocationComment> lstLMComment = new List<UserLocationComment>();
            lstLMComment.Add(userLocationComment);
            var mockLM = new Mock<ILocationBasedComment>();
            mockLM.Setup(x => x.GetUserLocationComment(1809)).Returns(lstLMComment);

        }
    }
}
