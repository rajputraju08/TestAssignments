﻿using System;
using System.Collections.Generic;
using System.Text;
using TigerSpike.LM.App.DataAccess;
using TigerSpike.LM.App.DataAccess.Models;
using TigerSpike.LM.App.BusinessLogic.BusinessEntities;
namespace TigerSpike.LM.App.BusinessLogic
{
    public interface ILocationBasedComment
    {
        List<UserLocationComment> GetUserLocationComment(int userId);
        List<UserLocationComment> GetAllUserLocationComment();

        List<UserLocationComment> GetUserCommentsByUserOrLocation(string userName, string locationName);

       bool AddCurrentLocationComments(UserLocationComment userLocationComment);
        
    }
}
