﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using TigerSpike.LM.App.BusinessLogic.BusinessEntities;
using TigerSpike.LM.App.DataAccess.Models;

namespace TigerSpike.LM.App.BusinessLogic
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            CreateMap<UserLocationComment, LocationComments>();
            CreateMap< LocationComments, UserLocationComment>();
            CreateMap<List<LocationComments>, List<UserLocationComment>>();
        }
    }

}
