﻿using System;
using System.Collections.Generic;
using TigerSpike.LM.App.BusinessLogic.BusinessEntities;
using TigerSpike.LM.App.DataAccess.Context;
using AutoMapper;
using TigerSpike.LM.App.DataAccess.Models;
using System.Linq;

namespace TigerSpike.LM.App.BusinessLogic
{
    public class LocationBasedComment : ILocationBasedComment
    {


        private readonly IMapper _mapper;
        public bool AddCurrentLocationComments(UserLocationComment userLocationComment)
        {
            //throw new NotImplementedException();
            try
            {
                using (var dbLMContext = new LMContext())
                {
                    LocationComments locationComments;                    
                    locationComments = _mapper.Map<UserLocationComment, LocationComments>(userLocationComment);
                    dbLMContext.Add(locationComments); 
                    dbLMContext.SaveChanges();
                    return true;
                }
            }
            catch(Exception ex)
            {
                return false;
            }

        }
       

        public List<UserLocationComment> GetAllUserLocationComment()
        {
            using(var dbLMContext = new LMContext() )
            {
                List<LocationComments> listUserComment = dbLMContext.LocationComments.ToList();                                     


                return _mapper.Map<List<LocationComments>,List<UserLocationComment>>(listUserComment);
            }

                       

         
        }

        public List<UserLocationComment> GetUserCommentsByUserOrLocation(string userName, string locationName)
        {
            using (var dbLMContext = new LMContext())
            {
                var listUserComment = dbLMContext.LocationComments.Where((p => p.User.UserName == userName || p.LocationName == locationName)).ToList();
                                    
                return _mapper.Map<List<LocationComments>, List<UserLocationComment>>(listUserComment);
            }
            
        }

        public List<UserLocationComment> GetUserLocationComment(int userId)
        {
            using (var dbLMContext = new LMContext())
            {
                var userComment = dbLMContext.LocationComments.Where(p => p.UserId == userId).ToList();
                                      
               
                return _mapper.Map<List<LocationComments>, List<UserLocationComment>>(userComment);
            }
            
        }
    }
}
